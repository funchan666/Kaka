(() => {
  /** @typedef {{id: string, title: string, format: string, genre: string, bpm: number, topic: string,
      style: string, host: string, description: string, exercise: string, cover?: string}} StageSession */
  /** @typedef {{id: string, name: string, style: string, portrait: string, bio: string}} ProgramHost */
  /** @type {ProgramHost[]} */
  const hosts = [
    {id: 'lan', name: '阿岚', style: '叙事 · 开放麦', portrait: 'host-lan.jpg',
      bio: '喜欢从街角的声音写起。一轮四小节，先听完故事再给反馈。'},
    {id: 'du', name: '老杜', style: '即兴 · 接力', portrait: 'host-du.jpg',
      bio: '把麦留给下一位，也留一个好接的尾字。偏爱现场接句和临时换拍。'},
    {id: 'mikee', name: '小麦', style: 'Boom Bap · 伴奏', portrait: 'host-mikee.jpg',
      bio: '从鼓组里找空拍，给每一轮不同速度。同样的句子，换一个落点再试。'},
  ];
  /** @type {StageSession[]} */
  const rooms = [
    {
      id: 'basement-mic', title: '地下麦克风', format: '开放麦', genre: 'open-mic', bpm: 92,
      topic: '末班地铁后的城市', style: 'story', host: 'lan', cover: 'cypher-cover.jpg',
      description: '给一段城市故事留四个小节。选一个角落、一种声音和一个路过的人，尽量用画面开场。',
      exercise: '第一小节说地点，第二小节写声音。第三、四小节收在同一个韵脚上。',
    },
    {
      id: 'back-to-back', title: '双麦接力', format: '即兴接力', genre: 'cypher', bpm: 106,
      topic: '在街角即兴接力', style: 'freestyle', host: 'du',
      description: '每轮四小节。接住上一句的尾词，用它开下一段，练习不掉拍的转场。',
      exercise: '从「路口」开口，四小节后用「回声」收尾。下一轮从「回声」继续。',
    },
    {
      id: 'breakbeat-room', title: '老派鼓点实验室', format: '伴奏拆解', genre: 'beats', bpm: 84,
      topic: '给旧唱片写新的一面', style: 'punch', host: 'mikee',
      description: '慢速 Boom Bap 节拍。把关键词放在第一拍，留一拍让鼓声露出来。',
      exercise: '第一拍重读关键词，第二、三拍填词。第四拍留白，听清下一轮的起拍。',
    },
    {
      id: 'hook-after-dark', title: '深夜副歌练习', format: '开放麦', genre: 'open-mic', bpm: 78,
      topic: '深夜写给自己的信', style: 'story', host: 'lan',
      description: '从一句能反复唱的短句开始，把副歌收在两个能记住的尾音上。',
      exercise: '先念一小节，再用同样的重音重复。第三、四小节缩短一句，找出你的副歌。',
    },
  ];

  const byID = new Map(rooms.map((room) => [room.id, room]));
  const hostByID = new Map(hosts.map((host) => [host.id, host]));
  const genres = [['all', '全部'], ['open-mic', '开放麦'], ['cypher', '即兴接力'], ['beats', '伴奏']];
  const reportReasons = ['内容不合适', '广告或垃圾信息', '侵犯隐私', '其他'];

  window.Kaka.catalog = {
    rooms: () => rooms.slice(),
    room: (id) => byID.get(id),
    host: (id) => hostByID.get(id),
    genres,
    reportReasons,
  };
})();
