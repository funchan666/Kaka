(() => {
  const Kaka = window.Kaka;
  const {get, element, message, notify, pending, confirm, records, lyrics, uuid} = Kaka;
  let score;
  let saved;
  let sourceRoom;
  let reveal = false;

  function renderScore() {
    get('score').hidden = !score;
    if (!score) return;
    get('score-title').textContent = score.topic;
    get('score-meta').textContent = [
      lyrics.styles[score.style].label, score.bpm + ' BPM', '4/4 拍', score.bars.length + ' 小节', score.scheme,
    ].join(' · ');
    const rows = [];
    let previous;
    for (const bar of score.bars) {
      if (bar.section !== previous) {
        rows.push(element('h3', 'bar-heading', bar.section));
        previous = bar.section;
      }
      const row = element('div', 'bar');
      const number = element('span', 'bar-index', String(bar.index).padStart(2, '0'));
      number.setAttribute('aria-hidden', 'true');
      const text = element('textarea');
      text.rows = 2;
      text.maxLength = 160;
      text.value = bar.text;
      text.setAttribute('aria-label', '第 ' + bar.index + ' 小节歌词');
      text.addEventListener('input', () => { bar.text = text.value; });
      row.append(number, text, element('p', 'caption', '目标韵脚 ' + bar.rhyme + ' · ' + bar.cue));
      rows.push(row);
    }
    get('score-bars').replaceChildren(...rows);
    message(get('score-error'));
  }

  function showResult() {
    if (!reveal || !score || get('notebook').hidden) return;
    reveal = false;
    const screen = get('notebook');
    const heading = get('score-title');
    heading.focus({preventScroll: true});
    const top = heading.getBoundingClientRect().top - screen.getBoundingClientRect().top;
    if (top > screen.clientHeight / 2 || top < 0) screen.scrollTop += top - 16;
  }

  function dirty() {
    return score && JSON.stringify(score) !== saved;
  }

  function fillForm(input) {
    get('verse-topic').value = input.topic;
    get('verse-bpm').value = input.bpm;
    const form = get('verse-form');
    for (const name of ['style', 'scheme', 'length']) {
      const value = name === 'length' ? String(input.bars?.length ?? 8) : input[name];
      for (const radio of form.querySelectorAll('input[name="' + name + '"]')) radio.checked = radio.value === value;
    }
    sourceRoom = input.roomID;
    const room = sourceRoom && Kaka.catalog.room(sourceRoom);
    message(get('verse-context'), room ? '取自「' + room.title + '」的主题和节拍' : '');
    message(get('verse-error'));
  }

  function useRoom(room) {
    fillForm({topic: room.topic, bpm: room.bpm, style: room.style, roomID: room.id, scheme: 'AABB'});
    reveal = false;
    get('notebook').scrollTop = 0;
    Kaka.go('notebook');
    requestAnimationFrame(() => { get('notebook').scrollTop = 0; });
  }

  async function openSaved(id) {
    const found = records.current().scores.find((item) => item.id === id);
    if (!found) {
      notify('这份草稿已移除。');
      return;
    }
    if (dirty() && score.id !== id && !await confirm({
      title: '打开另一份草稿？',
      description: '编辑区里还有未保存的词谱。继续会替换这份词谱。',
      label: '打开草稿',
    })) return;
    if (score?.id !== id) {
      saved = JSON.stringify(found);
      score = JSON.parse(saved);
      renderScore();
    }
    fillForm(score);
    reveal = true;
    Kaka.go('notebook');
    requestAnimationFrame(showResult);
  }

  function onDeleted(id) {
    if (score?.id !== id) return;
    if (dirty()) {
      score.id = uuid();
      score.createdAt = Date.now();
    } else {
      score = undefined;
    }
    saved = undefined;
    renderScore();
  }

  function init() {
    const form = get('verse-form');
    const formError = get('verse-error');
    const generate = form.querySelector('button[type="submit"]');
    const save = get('score-save');
    get('score-practice').addEventListener('click', () => {
      if (score) Kaka.cypher.carry(score);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const fields = new FormData(form);
      const topic = String(fields.get('topic') ?? '').trim();
      const bpm = Number(fields.get('bpm'));
      if (!topic || topic.length > 32) {
        message(formError, '请输入 1 至 32 字的主题。');
        get('verse-topic').focus();
        return;
      }
      if (!Number.isInteger(bpm) || bpm < 60 || bpm > 180) {
        message(formError, '速度请输入 60 至 180 之间的整数。');
        get('verse-bpm').focus();
        return;
      }
      message(formError);
      document.activeElement?.blur();
      pending(generate, async () => {
        if (dirty() && !await confirm({
          title: '生成新的词谱？',
          description: '新词谱会替换编辑区中的未保存内容。',
          label: '重新生成',
        })) return;
        score = await lyrics.provider.generate({
          topic, bpm, length: Number(fields.get('length')), scheme: fields.get('scheme'),
          style: fields.get('style'), roomID: sourceRoom ?? null,
        });
        saved = undefined;
        renderScore();
        reveal = true;
        showResult();
      }, (failure) => message(formError, failure.message));
    });

    save.addEventListener('click', () => pending(save, async () => {
      const error = get('score-error');
      message(error);
      if (!score) return;
      const current = score;
      const serializedBefore = JSON.stringify(current);
      const copy = JSON.parse(serializedBefore);
      copy.bars.forEach((bar) => { bar.text = bar.text.trim(); });
      const empty = copy.bars.find((bar) => !bar.text);
      if (empty) {
        message(error, '第 ' + empty.index + ' 小节没有歌词。');
        get('score-bars').querySelectorAll('textarea')[empty.index - 1].focus();
        return;
      }
      document.activeElement?.blur();
      copy.updatedAt = Date.now();
      await records.update((state) => {
        const index = state.scores.findIndex((item) => item.id === copy.id);
        if (index < 0 && state.scores.length >= 40) {
          throw new Error('草稿箱已满。删除一份草稿后再保存。');
        }
        if (index < 0) state.scores.push(copy);
        else state.scores[index] = copy;
      });
      if (score === current) {
        saved = JSON.stringify(copy);
        if (serializedBefore === JSON.stringify(score)) {
          score = copy;
          renderScore();
        }
      }
      notify('词谱已保存到草稿箱。');
    }, (error) => message(get('score-error'), error.message)));
  }

  Kaka.notebook = {init, useRoom, openSaved, onDeleted, showResult};
})();
