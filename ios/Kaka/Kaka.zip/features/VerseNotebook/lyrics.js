(() => {
  /** @typedef {{topic: string, style: string, bpm: number, length: number, scheme: string, roomID: string|null}} VerseRequest */
  /** @typedef {{index: number, section: string, text: string, rhyme: string, cue: string}} LyricBar */
  /** @typedef {{id: string, topic: string, style: string, bpm: number, scheme: string, roomID: string|null,
      bars: LyricBar[], createdAt: number, updatedAt: number}} VerseScore */
  const {uuid} = window.Kaka;
  const rhymeBanks = [
    {key: 'ang', tails: ['还留一束光', '街声钻过半开的窗', '回音格外响', '旧纸还能写很长', '借夜色开嗓', '让字落在街上', '握紧一点倔强', '给尾音留个空场']},
    {key: 'eng', tails: ['慢慢吹成风', '正好亮起灯', '藏在这座城', '留下几层回声', '站牌底下等一程', '又和夜色重逢', '耳边响起钟声', '鼓落下刚好无声']},
    {key: 'an', tails: ['心事还没说完', '换个方向靠岸', '在下一站折返', '转身已经太晚', '脚步拐了个弯', '把长句折成两段', '新的一页翻完', '和鼓点慢慢交谈']},
    {key: 'ou', tails: ['拍子在掌心走', '灯亮在巷口', '最后一拍慢收', '拐角还有个路口', '让这一句停在身后', '和回声交朋友', '不用找新的理由', '鼓点留在我心头']},
  ];

  const styles = {
    story: {
      label: '叙事',
      lines: [
        '我把「主题」写进便笺', '经过熟悉的转角', '听见铁轨擦过深夜', '把没说出口的话留给明天',
        '拉紧风衣沿着街走', '我记得那个模糊的背影', '半张车票还夹在书里', '镜头拉远有人转身',
        '我把时间揉成一张纸', '脚印叠在昨天的台阶', '一句话没赶上那班车', '于是把停顿借给鼓点',
      ],
      hook: ['同一条路我又走一遍', '这次让脚步先说话', '把「主题」轻轻唱一遍', '等最后一个音落下'],
    },
    freestyle: {
      label: '即兴',
      lines: [
        '话题是「主题」我接住', '第一拍到了先别慌', '随手接住上一句尾音', '把绕口的地方交给重拍',
        '对着墙试一次回环', '尾字刚落我又起句', '脚步和节奏碰个面', '临场留给自己一点余地',
        '散场前再多接一轮', '把生硬的字轻轻推开', '走到中间换一下重心', '第二遍我放小声音',
      ],
      hook: ['把麦放低听一遍', '踩着同一个拍子来', '「主题」再接一轮', '我把下一拍留出来'],
    },
    punch: {
      label: '狠句',
      lines: [
        '开场先放「主题」这一句', '我把多余的形容词划掉', '低音敲下来像句判词', '留下能站住脚的两个字',
        '谁说重拍得用更大声', '真话落地能掀起灰', '一条旧磁带记得手劲', '押韵是下笔时的取舍',
        '每个停顿都算进节拍', '我把松散的那句揉皱', '高音收起让鼓面开口', '下一句短到能刻进黑胶',
      ],
      hook: ['字轻一点话更重', '一句够了给鼓空半拍', '「主题」放进最后四小节', '灯落下来我再收尾'],
    },
  };

  /** @param {VerseRequest} request @returns {VerseScore} */
  function generate({topic, style, bpm, length, scheme, roomID}) {
    if (!topic || topic.length > 32 || !styles[style] || ![4, 8, 16].includes(length)
      || !Number.isInteger(bpm) || bpm < 60 || bpm > 180 || !['AABB', 'ABAB'].includes(scheme)) {
      throw new Error('请检查主题、速度和小节设置。');
    }
    const pick = crypto.getRandomValues(new Uint32Array(2));
    const start = pick[0] % rhymeBanks.length;
    const banks = [rhymeBanks[start], rhymeBanks[(start + 1 + pick[1] % (rhymeBanks.length - 1)) % rhymeBanks.length]];
    const uses = [0, 0];
    const mode = styles[style];
    const bars = Array.from({length}, (_, index) => {
      const hook = length > 4 && index >= length - 4;
      const bankIndex = scheme === 'ABAB' ? index % 2 : Math.floor(index / 2) % 2;
      const bank = banks[bankIndex];
      const lead = hook ? mode.hook[index - (length - 4)] : mode.lines[index];
      const tail = bank.tails[(pick[1] + uses[bankIndex]) % bank.tails.length];
      uses[bankIndex] += 1;
      return {
        index: index + 1,
        section: hook ? '副歌' : '主歌',
        text: lead.replace('主题', () => topic) + '，' + tail,
        rhyme: bank.key,
        cue: (index + 1) % 4 === 0 ? '尾拍换气' : (bpm >= 104 ? '切短词组' : '第一拍进'),
      };
    });
    const now = Date.now();
    return {id: uuid(), topic, style, bpm, scheme, roomID, bars, createdAt: now, updatedAt: now};
  }

  // The composer consumes this contract independently of the generation provider.
  window.Kaka.lyrics = {provider: {generate: async (request) => generate(request)}, styles};
})();
