(() => {
  const Kaka = window.Kaka;
  const {get, element, button, link, image, notify, message, pending, catalog, records} = Kaka;
  let filter = 'all';
  let detailID;
  const noteBuffer = new Map();

  function track(room, control, showHost = true) {
    control.classList.add('track');
    const host = showHost && catalog.host(room.host);
    const identity = element('span', 'track-identity');
    const copy = element('span', 'track-copy');
    copy.append(element('strong', '', room.title), element('span', 'caption', host ? host.name + ' · ' + room.format : room.format));
    if (host) identity.append(Kaka.creators.portrait(host, 'track-avatar'));
    identity.append(copy);
    control.append(identity, element('span', 'track-bpm', room.bpm + ' BPM'));
    return control;
  }

  function renderLineup() {
    const rooms = catalog.rooms().filter((room) =>
      !records.isHidden(room.id) && (filter === 'all' || room.genre === filter));
    const root = get('stage-lineup');
    root.replaceChildren();
    if (rooms.length === 0) {
      root.append(element('p', 'empty', '这个分类暂无可查看的场次。'));
      return;
    }
    const hero = rooms.find((room) => room.cover);
    if (hero) {
      const poster = element('article', 'feature');
      const title = element('div');
      title.append(element('h2', '', hero.title), element('p', 'caption', hero.format + ' · ' + hero.bpm + ' BPM'));
      const host = catalog.host(hero.host);
      if (host) title.append(Kaka.creators.hostLink(host, 'stage'));
      const info = element('div', 'feature-text');
      info.append(title, link('查看房间', 'room/' + hero.id, 'button primary'));
      poster.append(image(hero.cover, 'feature-image', '两位说唱表演者在小型舞台交流'), info);
      root.append(poster);
    }
    const remaining = rooms.filter((room) => room !== hero);
    if (remaining.length) {
      const list = element('section', 'room-list');
      list.setAttribute('aria-label', '节目列表');
      if (hero) list.append(element('h2', 'section-title', '更多场次'));
      remaining.forEach((room) => {
        const entry = link('', 'room/' + room.id, 'track');
        list.append(track(room, entry));
      });
      root.append(list);
    }
  }

  function init() {
    const controls = catalog.genres.map(([id, label]) => {
      const chip = button(label, () => {
        filter = id;
        controls.forEach((item) => item.setAttribute('aria-pressed', String(item === chip)));
        renderLineup();
      }, 'chip');
      chip.setAttribute('aria-pressed', String(id === filter));
      return chip;
    });
    get('stage-filters').replaceChildren(...controls);
  }

  function favoriteLabel(room) {
    return records.current().favorites.includes(room.id) ? '取消收藏' : '收藏场次';
  }

  function noteForm(room) {
    const form = element('form', 'note-form');
    const label = element('label', 'field', '排练笔记');
    const field = element('textarea');
    field.placeholder = '记下要练的四小节或尾韵';
    field.rows = 3;
    field.maxLength = 480;
    const persisted = records.current().notes.find((note) => note.roomID === room.id)?.text ?? '';
    field.value = noteBuffer.get(room.id) ?? persisted;
    field.addEventListener('input', () => noteBuffer.set(room.id, field.value));
    label.append(field);
    const submit = element('button', 'button secondary', '保存笔记');
    submit.type = 'submit';
    const error = element('p', 'field-error');
    error.hidden = true;
    error.setAttribute('role', 'status');
    form.append(label, submit, error);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const raw = field.value;
      const text = raw.trim();
      field.blur();
      message(error);
      pending(submit, async () => {
        await records.update((state) => {
          state.notes = state.notes.filter((note) => note.roomID !== room.id);
          if (text) state.notes.push({roomID: room.id, text});
        });
        if (field.value === raw) {
          noteBuffer.delete(room.id);
          field.value = text;
        }
        notify(text ? '排练笔记已保存。' : '排练笔记已清空。');
      }, (failure) => message(error, failure.message));
    });
    return form;
  }

  function reportForm(room, onDismiss) {
    const form = element('form', 'report-form');
    const choices = element('fieldset');
    choices.append(element('legend', '', '选择举报原因'));
    const options = element('div', 'chips');
    catalog.reportReasons.forEach((reason) => {
      const label = element('label', 'choice');
      const radio = element('input');
      radio.type = 'radio';
      radio.name = 'reason';
      radio.value = reason;
      label.append(radio, element('span', '', reason));
      options.append(label);
    });
    choices.append(options);
    const error = element('p', 'field-error');
    error.hidden = true;
    error.setAttribute('role', 'status');
    const action = element('div', 'button-row');
    const submit = element('button', 'button secondary', '隐藏并记录');
    submit.type = 'submit';
    action.append(submit, button('取消', onDismiss, 'button quiet'));
    form.append(choices, element('p', 'caption', '原因保存在设备上，可在「我的」恢复此场次。'), action, error);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const reason = new FormData(form).get('reason');
      if (!catalog.reportReasons.includes(reason)) {
        message(error, '请选择一个原因。');
        return;
      }
      message(error);
      pending(submit, async () => {
        await records.update((state) => {
          if (!state.reports.some((report) => report.roomID === room.id)) {
            state.reports.push({roomID: room.id, reason, createdAt: Date.now()});
          }
        });
        if (location.hash === '#room/' + room.id) Kaka.go('stage', true);
        notify('已隐藏该场次。');
      }, (failure) => message(error, failure.message));
    });
    return form;
  }

  function roomDetail(room) {
    if (detailID === room.id) return;
    detailID = room.id;
    const root = get('room-detail');
    const back = link('返回节目单', 'stage', 'button quiet room-back');
    const heading = element('h1', '', room.title);
    heading.id = 'room-title';
    heading.tabIndex = -1;
    const meta = element('p', 'caption', room.format + ' · ' + room.bpm + ' BPM');
    const summary = element('p', 'room-summary', room.description);

    const actions = element('div', 'button-row room-tools');
    const favorite = button(favoriteLabel(room), () => pending(favorite, async () => {
      await records.update((state) => {
        const index = state.favorites.indexOf(room.id);
        if (index >= 0) state.favorites.splice(index, 1);
        else state.favorites.push(room.id);
      });
      notify(records.current().favorites.includes(room.id) ? '场次已收藏。' : '已取消收藏。');
    }));
    favorite.id = 'room-favorite';
    actions.append(
      button('进入排练', () => Kaka.cypher.enter(room.id), 'button primary'),
      button('按场次写词', () => Kaka.notebook.useRoom(room)),
      favorite,
    );

    let report;
    const reportToggle = button('举报或隐藏', () => {
      report.hidden = !report.hidden;
      reportToggle.setAttribute('aria-expanded', String(!report.hidden));
      if (!report.hidden) report.querySelector('input').focus();
    }, 'button quiet');
    reportToggle.setAttribute('aria-expanded', 'false');
    report = reportForm(room, () => {
      report.hidden = true;
      reportToggle.setAttribute('aria-expanded', 'false');
      reportToggle.focus();
    });
    report.hidden = true;

    root.replaceChildren(back, heading, meta);
    if (room.cover) root.append(image(room.cover, 'room-art', '两位说唱表演者在小型舞台交流'));
    const host = catalog.host(room.host);
    if (host) root.append(Kaka.creators.hostLink(host, 'stage', '主持示例'));
    root.append(summary, actions, noteForm(room), reportToggle, report);
  }

  function refresh() {
    renderLineup();
    const liveDetail = detailID && catalog.room(detailID);
    if (!liveDetail) return;
    if (records.isHidden(liveDetail.id)) detailID = undefined;
    else get('room-favorite').textContent = favoriteLabel(liveDetail);
  }

  Kaka.stage = {init, refresh, roomDetail, track};
})();
