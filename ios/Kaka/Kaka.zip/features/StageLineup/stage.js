(() => {
  const Kaka = window.Kaka;
  const {get, element, button, link, image, actionIcon, notify, message, pending, catalog, records} = Kaka;
  let filter = 'all';
  let visibleRooms = [];
  let detailID;
  let preview;
  const noteBuffer = new Map();

  function track(room, control, showHost = true) {
    control.classList.add('track');
    const host = showHost && catalog.host(room.host);
    const identity = element('span', 'track-identity');
    const copy = element('span', 'track-copy');
    copy.append(element('strong', '', room.title), element('span', 'caption', host ? host.name + ' · ' + room.format : room.format));
    if (room.cover) {
      const media = element('span', 'track-media');
      media.append(image(room.cover, 'track-cover'));
      if (host) media.append(Kaka.creators.portrait(host, 'track-avatar'));
      identity.append(media);
    } else if (host) {
      identity.append(Kaka.creators.portrait(host, 'host-avatar'));
    }
    identity.append(copy);
    control.append(identity, element('span', 'track-bpm', room.bpm + ' BPM'));
    return control;
  }

  function stopPreview() {
    preview?.stop();
  }

  function clearPreview() {
    preview?.dispose();
    preview = undefined;
  }

  function previewScreen(room) {
    const screen = element('div', 'feature-screen');
    const top = element('div', 'feature-header');
    const tempo = element('span', 'tempo-badge', room.bpm + ' BPM');
    const label = element('span', 'preview-label', 'Stage preview');
    const poster = 'assets/previews/' + room.preview + '.jpg';
    const cover = element('img', 'feature-image');
    cover.alt = '';
    cover.src = poster;
    top.append(label, tempo);
    screen.append(cover, top);

    const video = element('video', 'feature-video');
    video.src = 'assets/previews/' + room.preview + '.mp4';
    video.poster = poster;
    video.preload = 'none';
    video.muted = true;
    video.playsInline = true;
    video.setAttribute('aria-hidden', 'true');

    const controls = element('div', 'preview-controls');
    const toggle = actionIcon(button('', togglePlayback, 'button primary preview-toggle'), 'action-play.png', 'Play stage preview');
    const glyph = toggle.querySelector('img');
    const progress = element('progress', 'preview-progress');
    progress.max = 1;
    progress.value = 0;
    progress.setAttribute('aria-label', 'Stage preview progress');
    controls.append(toggle, progress);
    screen.append(video, controls);
    screen.dataset.preview = 'idle';
    let request = 0;

    function setState(state) {
      screen.dataset.preview = state;
      const idle = state === 'idle';
      glyph.src = 'assets/images/action-' + (idle ? 'play' : 'stop') + '.png';
      toggle.setAttribute('aria-label', idle ? 'Play stage preview' : 'Stop stage preview');
      label.textContent = {idle: 'Stage preview', starting: 'Loading preview…', playing: 'Preview playing'}[state];
    }

    function stop() {
      if (screen.dataset.preview === 'idle') return;
      request += 1;
      video.pause();
      if (video.readyState > 0 && !video.error) video.currentTime = 0;
      progress.value = 0;
      setState('idle');
    }

    function fail() {
      if (screen.dataset.preview === 'idle') return;
      stop();
      notify('The stage preview could not play.');
    }

    async function togglePlayback() {
      if (screen.dataset.preview !== 'idle') {
        stop();
        return;
      }
      const started = ++request;
      setState('starting');
      try {
        await video.play();
        if (request !== started) return;
        if (video.paused) stop();
        else setState('playing');
      } catch {
        if (request === started) fail();
      }
    }

    video.addEventListener('timeupdate', () => {
      if (screen.dataset.preview !== 'idle' && Number.isFinite(video.duration) && video.duration > 0) {
        progress.value = video.currentTime / video.duration;
      }
    });
    video.addEventListener('ended', stop);
    video.addEventListener('error', fail);
    video.addEventListener('pause', () => {
      if (video.paused && screen.dataset.preview === 'playing') stop();
    });
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.intersectionRatio < .15) stop();
    }, {root: get('room'), threshold: .15});
    observer.observe(screen);
    preview = {
      stop,
      dispose() {
        stop();
        observer.disconnect();
        video.removeAttribute('src');
        video.load();
      },
    };
    return screen;
  }

  function roomCard(room, banner = false) {
    const card = link('', 'room/' + room.id, 'stage-card');
    const media = element('div', 'stage-card-media');
    const cover = image(banner ? room.banner : (room.cover ?? 'stage.jpg'), 'stage-card-image');
    cover.decoding = 'async';
    if (!banner) cover.loading = 'lazy';
    media.append(cover);

    const copy = element('div', 'stage-card-copy');
    const byline = element('div', 'stage-card-byline');
    const host = catalog.host(room.host);
    const credit = host ? host.name + ' · ' + room.format : room.format;
    if (host) byline.append(Kaka.creators.portrait(host, 'stage-card-avatar'));
    byline.append(element('span', '', credit));
    copy.append(element('h3', 'stage-card-title', room.title), byline);
    card.append(media, copy);

    if (banner) {
      const arrow = element('span', 'stage-banner-arrow');
      arrow.append(image('action-forward.png', 'action-icon'));
      card.append(arrow);
    } else {
      card.append(element('span', 'stage-card-tempo', room.bpm + ' BPM'));
    }
    return card;
  }

  function renderFeatured() {
    const featured = visibleRooms.filter((room) => room.banner);
    get('stage-featured-list').replaceChildren(...featured.map((room) => roomCard(room, true)));
    get('stage-featured').hidden = !featured.length;
  }

  function matchesFilter(room) {
    return filter === 'all' || room.genre === filter;
  }

  function renderRooms() {
    const rooms = visibleRooms.filter(matchesFilter);
    const grid = get('stage-room-grid');
    grid.replaceChildren(...rooms.map((room) => roomCard(room)));
    grid.hidden = !rooms.length;
    get('stage-empty').hidden = Boolean(rooms.length);
    if (rooms.length) return;
    get('stage-empty-message').textContent = filter === 'all' ? 'No rooms to show.' : 'No rooms in this category.';
    get('stage-restore-rooms').hidden = !catalog.rooms().some((room) => matchesFilter(room) && records.isHidden(room.id));
  }

  function init() {
    const controls = catalog.genres.map(([id, label]) => {
      const chip = button(label, () => {
        filter = id;
        controls.forEach((item) => item.setAttribute('aria-pressed', String(item === chip)));
        renderRooms();
      }, 'chip');
      chip.setAttribute('aria-controls', 'stage-room-grid');
      chip.setAttribute('aria-pressed', String(id === filter));
      return chip;
    });
    get('stage-filters').replaceChildren(...controls);
    window.addEventListener('kaka:pause', stopPreview);
    window.addEventListener('pagehide', stopPreview);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stopPreview();
    });
  }

  function renderFavorite(control, room) {
    const saved = records.current().favorites.includes(room.id);
    control.setAttribute('aria-pressed', String(saved));
    control.setAttribute('aria-label', saved ? 'Remove from saved rooms' : 'Save room');
  }

  function noteForm(room) {
    const form = element('form', 'note-form');
    const label = element('label', 'field', 'Rehearsal note');
    const field = element('textarea');
    field.placeholder = 'Jot down a bar or a rhyme to try';
    field.rows = 3;
    field.maxLength = 480;
    const persisted = records.current().notes.find((note) => note.roomID === room.id)?.text ?? '';
    field.value = noteBuffer.get(room.id) ?? persisted;
    field.addEventListener('input', () => noteBuffer.set(room.id, field.value));
    label.append(field);
    const submit = element('button', 'button secondary', 'Save note');
    submit.type = 'submit';
    actionIcon(submit, 'action-check.png');
    const error = element('p', 'field-error');
    error.hidden = true;
    error.setAttribute('role', 'status');
    form.append(label, submit, error);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const raw = field.value;
      const text = raw.trim();
      field.blur();
      message(error);
      pending(submit, async () => {
        await records.update((state) => {
          state.notes = state.notes.filter((note) => note.roomID !== room.id);
          if (text) state.notes.push({roomID: room.id, text});
        });
        if (field.value === raw) {
          noteBuffer.delete(room.id);
          field.value = text;
        }
        notify(text ? 'Rehearsal note saved.' : 'Rehearsal note cleared.');
      }, (failure) => message(error, failure.message));
    });
    return form;
  }

  function reportForm(room, onDismiss) {
    const form = element('form', 'report-form');
    const choices = element('fieldset');
    choices.append(element('legend', '', 'Why are you hiding this room?'));
    const options = element('div', 'chips');
    catalog.reportReasons.forEach((reason) => {
      const label = element('label', 'choice');
      const radio = element('input');
      radio.type = 'radio';
      radio.name = 'reason';
      radio.value = reason;
      label.append(radio, element('span', '', reason));
      options.append(label);
    });
    choices.append(options);
    const error = element('p', 'field-error');
    error.hidden = true;
    error.setAttribute('role', 'status');
    const action = element('div', 'button-row');
    const submit = element('button', 'button secondary', 'Hide room');
    submit.type = 'submit';
    action.append(submit, button('Cancel', onDismiss, 'button quiet'));
    form.append(choices, element('p', 'caption', 'You can restore this room from Profile.'), action, error);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const reason = new FormData(form).get('reason');
      if (!catalog.reportReasons.includes(reason)) {
        message(error, 'Choose a reason to continue.');
        return;
      }
      message(error);
      pending(submit, async () => {
        await records.update((state) => {
          if (!state.reports.some((report) => report.roomID === room.id)) {
            state.reports.push({roomID: room.id, reason, createdAt: Date.now()});
          }
        });
        if (location.hash === '#room/' + room.id) Kaka.go('stage', true);
        notify('Room hidden.');
      }, (failure) => message(error, failure.message));
    });
    return form;
  }

  function roomDetail(room) {
    if (detailID === room.id) return;
    clearPreview();
    detailID = room.id;
    const root = get('room-detail');
    const back = actionIcon(link('', 'stage', 'button quiet room-back'), 'action-forward.png', 'Back to Live Rooms');
    const heading = element('h1', '', room.title);
    heading.id = 'room-title';
    heading.tabIndex = -1;
    const meta = element('p', 'caption', room.preview ? room.format : room.format + ' · ' + room.bpm + ' BPM');
    const scene = element('header', 'scene room-scene');
    if (room.preview) {
      scene.classList.add('with-preview');
      scene.append(previewScreen(room));
    } else if (room.cover) {
      scene.append(image(room.cover, 'scene-art'));
    }
    const details = element('div', 'scene-heading');
    const title = element('div', 'scene-title');
    title.append(heading, meta);
    details.append(title);
    const host = catalog.host(room.host);
    if (host) details.append(Kaka.creators.hostLink(host, 'stage', 'Host'));
    scene.append(back, details);

    const brief = element('div', 'room-brief');
    brief.append(element('h2', 'section-title', room.topic), element('p', 'caption', room.description));
    const note = element('details', 'section-disclosure room-note');
    const noteToggle = element('summary', 'disclosure-summary');
    noteToggle.append(element('span', '', 'Rehearsal note'), image('action-forward.png', 'action-icon'));
    note.append(noteToggle, noteForm(room));

    const actions = element('div', 'button-row room-tools');
    const favorite = button('', () => pending(favorite, async () => {
      await records.update((state) => {
        const index = state.favorites.indexOf(room.id);
        if (index >= 0) state.favorites.splice(index, 1);
        else state.favorites.push(room.id);
      });
      notify(records.current().favorites.includes(room.id) ? 'Room saved.' : 'Room removed from saved rooms.');
    }));
    favorite.id = 'room-favorite';
    actionIcon(favorite, 'action-bookmark.png', 'Save room');
    renderFavorite(favorite, room);
    actions.append(
      actionIcon(button('Rehearse', () => Kaka.cypher.enter(room.id), 'button primary'), 'tab-voice.png'),
      actionIcon(button('', () => Kaka.notebook.useRoom(room)), 'action-edit.png', 'Write a verse'),
      favorite,
    );

    let report;
    const reportToggle = button('Hide or flag room', () => {
      report.hidden = !report.hidden;
      reportToggle.setAttribute('aria-expanded', String(!report.hidden));
      if (!report.hidden) report.querySelector('input').focus();
    }, 'button quiet');
    reportToggle.setAttribute('aria-expanded', 'false');
    report = reportForm(room, () => {
      report.hidden = true;
      reportToggle.setAttribute('aria-expanded', 'false');
      reportToggle.focus();
    });
    report.hidden = true;

    root.replaceChildren(scene, actions, brief, note, reportToggle, report);
  }

  function refresh() {
    const rooms = catalog.rooms().filter((room) => !records.isHidden(room.id));
    if (!visibleRooms.length || rooms.length !== visibleRooms.length
      || rooms.some((room, index) => room !== visibleRooms[index])) {
      visibleRooms = rooms;
      renderFeatured();
      renderRooms();
    }
    const liveDetail = detailID && catalog.room(detailID);
    if (!liveDetail) return;
    if (records.isHidden(liveDetail.id)) {
      detailID = undefined;
      clearPreview();
    } else {
      renderFavorite(get('room-favorite'), liveDetail);
    }
  }

  function reset() {
    clearPreview();
    filter = 'all';
    visibleRooms = [];
    detailID = undefined;
    noteBuffer.clear();
    get('room-detail').replaceChildren();
    Array.from(get('stage-filters').children).forEach((chip, index) =>
      chip.setAttribute('aria-pressed', String(index === 0)));
  }

  Kaka.stage = {init, refresh, reset, roomDetail, track, stopPreview};
})();
