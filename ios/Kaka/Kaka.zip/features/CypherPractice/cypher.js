(() => {
  /** @typedef {'idle' | 'starting' | 'practicing'} PracticeStatus */
  const Kaka = window.Kaka;
  const {get, element, link, image, message, notify, catalog, records} = Kaka;
  let visibleRooms = [];
  let selectedID;
  let seatedID;
  let carried;
  let audio;
  let interval;
  let generation = 0;
  const pendingBeats = new Set();

  function room() {
    return catalog.room(selectedID);
  }

  function practiceTarget() {
    return room() ?? visibleRooms[0];
  }

  function updateQuickPractice() {
    const target = practiceTarget();
    get('voice-quick').hidden = !target;
    if (target) {
      const bpm = carried?.roomID === target.id ? carried.score.bpm : target.bpm;
      get('voice-quick-room').textContent = target.title + ' · ' + bpm + ' BPM';
    }
  }

  function roomCard(entry) {
    const card = link('', 'voice/' + entry.id, 'voice-room-card');
    const media = element('div', 'voice-room-media');
    const cover = image(entry.cover ?? 'voice.jpg', 'voice-room-cover');
    cover.loading = 'lazy';
    cover.decoding = 'async';
    media.append(cover);
    const host = catalog.host(entry.host);
    if (host) media.append(Kaka.creators.portrait(host, 'voice-room-avatar'));

    const copy = element('div', 'voice-room-copy');
    const caption = (host ? host.name + ' · ' : '') + entry.bpm + ' BPM';
    copy.append(element('h3', 'voice-room-name', entry.title), element('span', 'voice-room-meta', caption));
    card.append(media, copy);
    return card;
  }

  function refresh() {
    const available = catalog.rooms().filter((entry) => !records.isHidden(entry.id));
    if (selectedID && !available.some((entry) => entry.id === selectedID)) {
      const wasOpen = location.hash === '#' + resumeRoute();
      stop();
      selectedID = undefined;
      if (wasOpen) Kaka.go('voice', true);
    }
    if (seatedID && !available.some((entry) => entry.id === seatedID)) {
      seatedID = undefined;
    }
    const grid = get('voice-rooms');
    if (available.length !== visibleRooms.length || available.some((entry, index) => entry !== visibleRooms[index])) {
      visibleRooms = available;
      grid.replaceChildren(...available.map(roomCard));
    }
    grid.hidden = !available.length;
    get('voice-empty').hidden = Boolean(available.length);
    updateQuickPractice();
    const selected = room();
    if (selected && location.hash === '#' + resumeRoute()) describe(selected);
  }

  function openRoom(entry) {
    selectedID = entry.id;
    describe(entry);
    updateQuickPractice();
  }

  function resumeRoute() {
    return selectedID ? 'voice/' + selectedID : 'voice';
  }

  function describe(entry) {
    const score = carried?.roomID === entry.id ? carried.score : null;
    const host = catalog.host(entry.host);
    const cover = get('practice-cover');
    cover.hidden = !entry.cover;
    if (entry.cover && cover.getAttribute('src') !== 'assets/images/' + entry.cover) {
      cover.src = 'assets/images/' + entry.cover;
    }
    get('voice-room-title').textContent = entry.title;
    get('practice-format').textContent = entry.format;
    get('practice-bpm').textContent = score ? score.bpm : entry.bpm;
    get('practice-prompt').textContent = entry.exercise;
    const hostSeat = get('practice-host');
    hostSeat.replaceChildren();
    hostSeat.hidden = !host;
    if (host) {
      const link = Kaka.creators.hostLink(host, 'voice', 'Host seat');
      link.classList.add('host-seat');
      hostSeat.append(link);
    }
    get('practice-verse').hidden = !score;
    if (score) {
      get('practice-verse-title').textContent = 'Rehearsing · ' + score.topic;
      get('practice-verse-lines').replaceChildren(...score.lines.map((line) => element('li', '', line)));
    }
    renderSeat();
    message(get('practice-error'));
  }

  function renderSeat() {
    const occupied = Boolean(selectedID && seatedID === selectedID);
    const seat = get('practice-seat');
    get('practice-seat-name').textContent = occupied ? records.current().profile.name : 'Your seat';
    get('practice-seat-action').textContent = occupied ? 'Leave seat' : 'Take a seat';
    const portrait = seat.querySelector('img');
    const source = 'assets/images/' + (occupied ? 'member-mark.jpg' : 'action-seat.png');
    if (portrait.getAttribute('src') !== source) portrait.src = source;
    seat.setAttribute('aria-pressed', String(occupied));
    get('beat-toggle').disabled = !occupied;
  }

  function showBeat(step = -1) {
    Array.from(get('beats').children).forEach((item, index) => item.classList.toggle('active', index === step));
  }

  /** @param {PracticeStatus} state */
  function setControls(state) {
    const toggle = get('beat-toggle');
    const running = state !== 'idle';
    toggle.setAttribute('aria-pressed', String(running));
    toggle.setAttribute('aria-label', {idle: 'Start the beat', starting: 'Cancel beat startup', practicing: 'Stop the beat'}[state]);
    get('beat-play-icon').hidden = running;
    get('beat-stop-icon').hidden = !running;
    get('practice').dataset.beatState = state;
    get('beat-status').textContent = {idle: '4/4 time', starting: 'Starting…', practicing: 'Beat playing'}[state];
  }

  function stop() {
    generation += 1;
    clearInterval(interval);
    interval = undefined;
    pendingBeats.forEach((timer) => clearTimeout(timer));
    pendingBeats.clear();
    if (audio) {
      const previous = audio;
      audio = undefined;
      previous.close().catch(() => {});
    }
    setControls('idle');
    showBeat();
  }

  function scheduleClick(context, time, accented) {
    const wave = context.createOscillator();
    const volume = context.createGain();
    wave.type = 'sine';
    wave.frequency.value = accented ? 1220 : 800;
    volume.gain.setValueAtTime(.0001, time);
    volume.gain.exponentialRampToValueAtTime(accented ? .19 : .12, time + .003);
    volume.gain.exponentialRampToValueAtTime(.0001, time + .045);
    wave.connect(volume);
    volume.connect(context.destination);
    wave.start(time);
    wave.stop(time + .05);
    wave.onended = () => {
      wave.disconnect();
      volume.disconnect();
    };
  }

  async function start() {
    const selected = room();
    if (!selected || seatedID !== selectedID || audio) return;
    const token = ++generation;
    const toggle = get('beat-toggle');
    const error = get('practice-error');
    const Audio = window.AudioContext || window.webkitAudioContext;
    message(error);
    if (!Audio) {
      message(error, 'Beat playback is unavailable.');
      return;
    }
    let timeout;
    try {
      const context = new Audio();
      audio = context;
      setControls('starting');
      await Promise.race([
        context.resume(),
        new Promise((_, reject) => { timeout = setTimeout(reject, 2200); }),
      ]);
      if (token !== generation) return;
      if (toggle.closest('[hidden]')) {
        stop();
        return;
      }
      context.addEventListener('statechange', () => {
        if (token === generation && context.state !== 'running') stop();
      });
      setControls('practicing');
      const bpm = carried?.roomID === selected.id ? carried.score.bpm : selected.bpm;
      const duration = 60 / bpm;
      let next = context.currentTime + .055;
      let beat = 0;
      const tick = () => {
        const now = context.currentTime;
        if (next < now - duration) {
          next = now + .035;
          beat = 0;
        }
        while (next < now + .11) {
          const step = beat % 4;
          scheduleClick(context, Math.max(now, next), step === 0);
          const timer = setTimeout(() => {
            pendingBeats.delete(timer);
            if (generation === token) showBeat(step);
          }, Math.max(0, (next - now) * 1000));
          pendingBeats.add(timer);
          beat += 1;
          next += duration;
        }
      };
      tick();
      interval = setInterval(tick, 35);
    } catch {
      if (generation === token) {
        stop();
        message(error, 'The beat could not play. Try again.');
      }
    } finally {
      clearTimeout(timeout);
    }
  }

  function enter(id) {
    if (!catalog.room(id) || records.isHidden(id)) return;
    seatedID = id;
    Kaka.go('voice/' + id);
  }

  function carry(score) {
    const target = visibleRooms.find((entry) => entry.id === score.roomID) ?? practiceTarget();
    if (!target) {
      notify('Restore a room in Profile before rehearsing.');
      return;
    }
    const lines = score.bars.map((bar) => bar.text.trim());
    if (lines.some((line) => !line)) {
      notify('Fill in every bar before rehearsing.');
      return;
    }
    stop();
    carried = {roomID: target.id, score: {topic: score.topic, bpm: score.bpm, lines}};
    enter(target.id);
    notify('Verse ready to rehearse.');
  }

  function init() {
    get('voice-quick').addEventListener('click', () => {
      const target = practiceTarget();
      if (target) enter(target.id);
    });
    get('beat-toggle').addEventListener('click', () => {
      if (audio) stop();
      else start();
    });
    get('practice-write').addEventListener('click', () => {
      const selected = room();
      if (selected) Kaka.notebook.useRoom(selected);
    });
    get('practice-seat').addEventListener('click', () => {
      if (!room()) return;
      if (seatedID === selectedID) {
        seatedID = undefined;
        stop();
      } else {
        seatedID = selectedID;
      }
      renderSeat();
    });
    get('practice-drop-verse').addEventListener('click', () => {
      stop();
      carried = undefined;
      if (room()) describe(room());
      updateQuickPractice();
    });
    window.addEventListener('kaka:pause', stop);
    window.addEventListener('pagehide', stop);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stop();
    });
  }

  function reset() {
    stop();
    visibleRooms = [];
    selectedID = undefined;
    seatedID = undefined;
    carried = undefined;
    get('voice-rooms').replaceChildren();
    get('practice-verse-title').textContent = '';
    get('practice-verse-lines').replaceChildren();
  }

  Kaka.cypher = {init, refresh, reset, stop, openRoom, resumeRoute, enter, carry};
})();
